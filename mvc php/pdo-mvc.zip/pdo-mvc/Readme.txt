This directory presents a simple PHP application using the Model-View-Controller 
design pattern and the PDO interface to a Mysql database.

